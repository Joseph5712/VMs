<button <?php echo e($attributes->merge(['class' => 'rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600', 'type' => 'submit'])); ?>>
    <?php echo e($slot); ?>

</button><?php /**PATH /home/vagrant/sites/14days.isw811.xyz/resources/views/components/form-button.blade.php ENDPATH**/ ?>