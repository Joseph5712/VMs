<div class="sm:col-span-4">
    <?php echo e($slot); ?>

</div><?php /**PATH /home/vagrant/sites/14days.isw811.xyz/resources/views/components/form-field.blade.php ENDPATH**/ ?>