<x-layout>
    <x-slot:heading>
        Home Page
    </x-slot:heading>
</x-layout>