<div class="sm:col-span-4">
    {{ $slot }}
</div>